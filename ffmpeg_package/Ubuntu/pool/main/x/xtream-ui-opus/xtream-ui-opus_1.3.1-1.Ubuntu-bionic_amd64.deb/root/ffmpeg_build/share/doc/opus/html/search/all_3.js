var searchData=
[
  ['multistream_20specific_20encoder_20and_20decoder_20ctls',['Multistream specific encoder and decoder CTLs',['../group__opus__multistream__ctls.html',1,'']]]
];
