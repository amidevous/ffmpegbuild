var searchData=
[
  ['pre_2ddefined_20values_20for_20ctl_20interface',['Pre-defined values for CTL interface',['../group__opus__ctlvalues.html',1,'']]]
];
